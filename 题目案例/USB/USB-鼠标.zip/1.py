import matplotlib.pyplot as plt

def parse_hid_packet(hid_packet):
    """
    解析 HID 数据包，返回 X/Y 轴位移。
    """
    # 转换为字节列表
    data = [int(hid_packet[i:i+2], 16) for i in range(0, len(hid_packet), 2)]

    # X 和 Y 轴位移
    x_movement = data[1] if data[1] <= 127 else data[1] - 256
    y_movement = data[2] if data[2] <= 127 else data[2] - 256

    return x_movement, y_movement

# 打开 HID 数据文件
file_path = "usbdata.txt"
positions = [(0, 0)]  # 初始化鼠标位置 (x, y)

with open(file_path, "r") as file:
    for line in file:
        hid_packet = line.strip()
        if len(hid_packet) == 12:  # 确保是有效的 6 字节数据包
            dx, dy = parse_hid_packet(hid_packet)
            # 累加位移，更新鼠标位置
            last_x, last_y = positions[-1]
            positions.append((last_x + dx, last_y + dy))

# 提取 X 和 Y 坐标
x_coords, y_coords = zip(*positions)

# 绘制鼠标轨迹
plt.figure(figsize=(10, 6))
plt.plot(x_coords, y_coords, marker="o", markersize=2, linestyle="-", color="blue")
plt.title("Mouse Movement Trajectory")
plt.xlabel("X Position")
plt.ylabel("Y Position")
plt.grid()
plt.show()
